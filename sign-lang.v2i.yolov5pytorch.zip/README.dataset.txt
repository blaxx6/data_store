# sign-lang > 2024-11-18 5:18pm
https://universe.roboflow.com/signlang-pfyv8/sign-lang-k5xgu

Provided by a Roboflow user
License: CC BY 4.0

